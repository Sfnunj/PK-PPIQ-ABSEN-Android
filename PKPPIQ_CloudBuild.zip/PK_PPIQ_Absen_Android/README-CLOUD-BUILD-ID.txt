PK PPIQ ABSEN — ANDROID WEBVIEW + CLOUD BUILD
==============================================

Aplikasi web: https://ppiqabsen.byethost16.com/
Application ID: id.ppiq.absen
Nama aplikasi: PK PPIQ ABSEN

CARA BUILD TANPA LAPTOP (MELALUI HP)
1. Ekstrak ZIP ini di HP jika aplikasi pengelola file mendukung ekstrak ZIP.
2. Buat akun GitHub di https://github.com/ (gratis).
3. Buat repository baru bernama PK-PPIQ-ABSEN-Android.
   - Pilih Public agar paling mudah mengikuti panduan.
   - Jangan centang Add README, .gitignore, atau license.
4. Unggah seluruh ISI folder PK_PPIQ_Absen_Android ke repository GitHub,
   termasuk folder tersembunyi .github/workflows/build-apk.yml.
   Penting: file build-apk.yml harus berada pada:
   .github/workflows/build-apk.yml
5. Buka tab Actions di repository.
6. Pilih workflow "Build APK PK PPIQ ABSEN".
7. Tekan Run workflow, lalu Run workflow sekali lagi untuk konfirmasi.
8. Tunggu sampai proses selesai dan status berubah hijau (Success).
9. Buka hasil run yang sukses, gulir ke bagian Artifacts.
10. Unduh artifact "PK-PPIQ-ABSEN-debug". Ekstrak ZIP artifact tersebut
    untuk memperoleh app-debug.apk.
11. Kirim app-debug.apk ke HP Android, buka file, lalu izinkan instalasi
    dari sumber tersebut jika Android meminta izin.

CATATAN
- Build berjalan di server GitHub Actions; tidak perlu Android Studio/SDK di HP.
- Workflow memakai Gradle 8.9, Java 17, Android SDK Platform 35 dan Build Tools 35.
- File hasil adalah APK debug untuk uji coba, bukan release bertanda tangan
  untuk distribusi publik.
- PHP/MySQL tetap berjalan di hosting; APK memerlukan internet.
- Jangan mengunggah kata sandi, file database, atau kredensial rahasia ke repo.
- Pastikan seluruh isi proyek, termasuk file dan folder tersembunyi, diunggah.
