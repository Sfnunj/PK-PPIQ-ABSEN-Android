PK PPIQ ABSEN — PROYEK ANDROID WEBVIEW
====================================

Alamat aplikasi: https://ppiqabsen.byethost16.com/
Application ID: id.ppiq.absen
Nama aplikasi: PK PPIQ ABSEN

FITUR
- Membuka aplikasi web online melalui Android WebView.
- JavaScript, DOM storage, dan cookie aktif untuk sesi login.
- Progress bar saat halaman dimuat.
- Tombol kembali Android mengikuti riwayat halaman.
- Pemilih file untuk fitur unggah foto/dokumen pada formulir web.
- Link eksternal, email, dan telepon dibuka melalui aplikasi yang sesuai.
- Layar pemuatan dan ikon aplikasi memakai logo resmi PK PPIQ yang diberikan pengguna.

CARA MEMBUAT APK (ANDROID STUDIO)
1. Ekstrak ZIP proyek ini.
2. Instal Android Studio versi stabil dan Android SDK Platform 35.
3. Buka folder PK_PPIQ_Absen melalui File > Open.
4. Tunggu Gradle Sync selesai. Pastikan komputer terhubung internet agar plugin Android Gradle diunduh.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik lokasi APK dari notifikasi Build. Umumnya berada di app/build/outputs/apk/debug/app-debug.apk.

CATATAN PENTING
- Proyek ini adalah source code Android, bukan APK yang sudah dikompilasi.
- PHP dan MySQL tetap berjalan di hosting. APK memerlukan internet dan tidak berisi database lokal.
- Uji semua alur login, absensi, unggah foto, rekap, dan logout di perangkat Android sebelum distribusi.
- APK debug untuk uji coba. Untuk dibagikan secara luas, buat signed release APK melalui Build > Generate Signed Bundle / APK.
- Pastikan domain dan sertifikat HTTPS hosting tetap aktif.

IDENTITAS VISUAL
- Logo resmi tersimpan di app/src/main/res/drawable/ppiq_logo.png.
- Salinan aset asli tersedia di folder ASSETS/logo-resmi-pk-ppiq.jpg.
